
from django.contrib import admin
from django.urls import path,include

urlpatterns = [
    # path('admin/main/', admin.site.urls),
    path('',include('ugs_app.urls'))
]
