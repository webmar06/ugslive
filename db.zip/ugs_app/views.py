from django.shortcuts import render,redirect
from django.http import JsonResponse,HttpResponseRedirect
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth import authenticate,login,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User,AbstractUser
from django.contrib.auth.admin import UserAdmin
from django.contrib import messages
from django.utils import timezone
from .models import UserAccount,UserWallet,Games,Bet,Fight,UserProfile
import datetime,time
import uuid
from django.contrib.auth.hashers import make_password
from django.db.models import Q
from django.utils.crypto import get_random_string
from .forms import SignUpForm,LoginForm,UserForm,WalletForm,GameForm,FightForm
from django.core import serializers
from django.core.serializers import serialize
import json
from .serializers import GameSerializer,FightSerializer,UserSerializer
from django.db.models import Sum
from django.utils import timezone



def index(request):
     # bets=Bet.objects.select_related('fight__f_game').all()
     # ldata=serialize('json',bets)
     # gdata=json.loads(ldata)

     if request.user.is_authenticated:
          print(request.user.useraccount.usertype)
          return redirect('homepage')
     referral=request.META['HTTP_HOST']+'/agent='+get_random_string(50)
     context={
          'page':'AUTHENTICATION',
          'login_frm':LoginForm()
     }
     return render(request,'ugs_app/auth/index.html',context)


@login_required(login_url='/')
def homepage(request):
     games=Games.objects.filter(g_status='OPEN')
     context={
          'page':'HOMEPAGE',
           'games':list(games)
     }
     return render(request,'ugs_app/homepage/index.html',context)

def games(request):
     games=Games.objects.filter(g_status='OPEN')
     context={
          'page':'GAMES',
          'games':list(games)
     }
     return render(request,'ugs_app/homepage/games.html',context)


def setting(request):
     context={
          'page':'SETTING'
     }
     return render(request,'ugs_app/homepage/setting.html',context)

def users(request):
     users=UserProfile.objects.all().order_by('-date_joined')

     context={
          'page':'USERS',
          'signup_frm':SignUpForm(),
          'user_frm':UserForm(),
          'users':list(users)
     }
     return render(request,'ugs_app/homepage/users.html',context)

@csrf_exempt
def upstat(request):
     aid=request.POST.get('acc_id')
     astat=request.POST.get('acc_stat')
     print(astat)
     try:
          guser=UserAccount.objects.get(user=aid)
          # print(guser.useraccount.status)
          guser.status=astat
          guser.save()
          print(guser)
          data='ok'
     except Exception as e:
          data='Error'
     return JsonResponse({'data':data})

@csrf_exempt
def getusers(request):
     acc=UserProfile.objects.all().select_related('useraccount',)
     data=[]
     for a in acc:
          a.date_joined=a.date_joined.strftime("%Y-%m-%d %I:%M %p")
          print(a.id)
          try:
               gwallet=UserWallet.objects.get(user=a)
               wallet=gwallet.w_balance
          except Exception as e:
               wallet=0
          res={
               'uid':a.id,
               'user':a.username,
               'type':a.useraccount.usertype,
               'agent':str(a.useraccount.user_agent),
               'wallet':wallet,
               'status':a.useraccount.status,
               'datejoin':a.date_joined

          }

          data.append(res)
     return JsonResponse({'data':data})
     
     # return JsonResponse(data,safe=False)

def arena(request,game_id):
     fstatus=''
     fid=''
     meron=0
     wala=0
     fnum=0
     mymeronbet=0
     mywalabet=0
     mydrawbet=0
     mylongbet=0

     try:
          g_arena=Games.objects.get(g_id=game_id)
          gname=g_arena.g_name
          gid=g_arena.g_id
          meron_name=g_arena.g_redname
          wala_name=g_arena.g_bluename

          try:
               g_fight=Fight.objects.filter(f_game=g_arena).latest('f_created')
               fid=g_fight.f_id
               status=g_fight.f_status
               fnum=g_fight.f_number
               fmulti=g_fight.f_multiplier
               fwin=g_fight.f_winner
               flong=g_fight.f_longest
               try:
                    mymeronbet=Bet.objects.filter(fight=g_fight,status='PENDING',category='MERON',player=request.user).aggregate(total=Sum('amount'))['total']
                    if mymeronbet is None:
                         mymeronbet=0
               except Exception as e:
                    mymeronbet=0
                    
               try:
                    mywalabet=Bet.objects.filter(fight=g_fight,status='PENDING',category='WALA',player=request.user).aggregate(total=Sum('amount'))['total'] 
                    if mywalabet is None:
                         mywalabet=0
               except Exception as e:
                    mywalabet=0
               
               try:
                    mydrawbet=Bet.objects.filter(fight=g_fight,status='PENDING',category='DRAW',player=request.user).aggregate(total=Sum('amount'))['total'] 
                    if mydrawbet is None:
                         mydrawbet=0
               except Exception as e:
                    mydrawbet=0
               try:
                    mylongbet=Bet.objects.filter(fight=g_fight,status='PENDING',category='LONGEST',player=request.user).aggregate(total=Sum('amount'))['total'] 
                    if mylongbet is None:
                         mylongbet=0
               except Exception as e:
                    mylongbet=0
               

               try:
                    meron=Bet.objects.filter(fight=fid,category='MERON').aggregate(total=Sum('amount'))['total']
                    if meron is None:
                         meron=0
               except Exception as e:
                    meron=0
               try:
                    wala=Bet.objects.filter(fight=fid,category='WALA').aggregate(total=Sum('amount'))['total'] 
                    if wala is None:
                         wala=0
               except Exception as e:
                    wala=0
               
               

          except Exception as e:
               status='CLOSED'
               fnum=0
               fmulti=0
               fwin=0
               flong=0
               fid=0

     except Exception as e:
          print(e)

     dmeron=float(meron)*float(fmulti)
     dwala=float(wala)*float(fmulti)
     wallet=UserWallet.objects.get(user=request.user)
     wbalance=wallet.w_balance
 
     context={
          'page':'ARENA',
          'game':game_id,
          'game_name':gname,
          'betstat':status,
          'fight_id':fid,
          'fnumber':fnum,
          'wallet':wbalance,
          'mybetmeron':mymeronbet,
          'mybetwala':mywalabet,
          'mydrawbet':mydrawbet,
          'mylongbet':mylongbet,

          'dmeron':dmeron,
          'dwala':dwala,

          'nmeron':meron_name,
          'nwala':wala_name

     }
     return render(request,'ugs_app/homepage/player_arena.html',context)

@csrf_exempt
def decla_arena(request,game_id):

     fform=FightForm()
     fstatus=''
     fid=''
     meron=0
     wala=0
     fnum=0
     try:
          g_arena=Games.objects.get(g_id=game_id)
          gname=g_arena.g_name
          gid=g_arena.g_id
          meron_name=g_arena.g_redname
          wala_name=g_arena.g_bluename

          try:
               g_fight=Fight.objects.filter(f_game=g_arena).latest('f_created')
               fid=g_fight.f_id
               status=g_fight.f_status
               fnum=g_fight.f_number
               fmulti=g_fight.f_multiplier
               fwin=g_fight.f_winner
               flong=g_fight.f_longest
               # try:
               #      mymeronbet=Bet.objects.filter(fight=g_fight,status='PENDING',category='MERON',player=request.user).aggregate(total=Sum('amount'))['total']
               #      if mymeronbet is None:
               #           mymeronbet=0
               # except Exception as e:
               #      mymeronbet=0
                    
               # try:
               #      mywalabet=Bet.objects.filter(fight=g_fight,status='PENDING',category='WALA',player=request.user).aggregate(total=Sum('amount'))['total'] 
               #      if mywalabet is None:
               #           mywalabet=0
               # except Exception as e:
               #      mywalabet=0

               try:
                    meron=Bet.objects.filter(fight=fid,category='MERON').aggregate(total=Sum('amount'))['total']
                    if meron is None:
                         meron=0
               except Exception as e:
                    meron=0
               try:
                    wala=Bet.objects.filter(fight=fid,category='WALA').aggregate(total=Sum('amount'))['total'] 
                    if wala is None:
                         wala=0
               except Exception as e:
                    wala=0
               try:
                    draw=Bet.objects.filter(fight=fid,category='DRAW').aggregate(total=Sum('amount'))['total'] 
                    if draw is None:
                         draw=0
               except Exception as e:
                    draw=0

               try:
                    long=Bet.objects.filter(fight=fid,category='LONGEST').aggregate(total=Sum('amount'))['total'] 
                    if long is None:
                         long=0
               except Exception as e:
                    long=0

          except Exception as e:
               status='NONE'
               fnum=0
               fmulti=0
               fwin=0
               flong=0
               fid=0
               draw=0
               long=0


     except Exception as e:
          print(e)
     
     dmeron=float(meron)*float(fmulti)
     dwala=float(wala)*float(fmulti)
     wallet=UserWallet.objects.get(user=request.user)
     wbalance=wallet.w_balance
 
     context={
          'page':'DECLA ARENA',
          'game':game_id,
          'game_name':gname,
          'meron':meron,
          'wala':wala,
          'draw':draw,
          'long':long,
          'status':status,
          'fnum':fnum,
          'fwin':fwin,
          'flong':flong,
          'multiplier':fmulti,
          'fform':fform,
          'fight_id':fid,
          'wallet':wbalance,
          # 'mybetmeron':mymeronbet,
          # 'mybetwala':mywalabet,
          'dmeron':dmeron,
          'dwala':dwala,
          'nmeron':meron_name,
          'nwala':wala_name
     }
     return render(request,'ugs_app/homepage/decla_arena.html',context)





# DECLARATOR
@csrf_exempt
def delgame(request):
     did=request.POST.get('did')
     dgames=Games.objects.get(g_id=did).delete()
     if dgames:
          data='ok'
     else:
          data='Failed'
     return JsonResponse({'data':data})



@csrf_exempt
def gfight(request):
     gid=request.POST.get('gfid')
     game=Games.objects.get(g_id=gid)
     try:
          gf=Fight.objects.filter(f_game=game).latest('f_created')
          fid=gf.f_id
          fnum=gf.f_number
          fmulti=gf.f_multiplier
          fstat=gf.f_status
          fwin=gf.f_winner
          flong=gf.f_longest
     except Exception as e:
          fid=0
          fnum=0
          fmulti=0
          fwin=''
          flong=0
          fstat='CLOSED'
 
     data={
          'game':game.g_id,
          'fight':fid,
          'fnum':fnum,
          'fmulti':fmulti,
          'fstat':fstat,
          'fwin':fwin,
          'flong':flong
     }
     
     return JsonResponse({'data':data})

@csrf_exempt
def addfight(request):

     fform=FightForm(request.POST or None)
     gid=request.POST.get('fgame')
     f_id=request.POST.get('f_id')
     typ=request.POST.get('f_type')
     code=get_random_string(6)
     fnum=request.POST.get('f_number')
     print(fnum)
          
     if typ is None:
          try:
               ckfight=Fight.objects.get(f_id=f_id,f_number=fnum)
               data='exist'
          except Exception as e:
           if fform.is_valid():
               nf = fform.save(commit=False)
               nf.f_code=code
               nf.f_status='CLOSED'
               nf.save()
               data='insert'
           else:
               data='Invalid Form'
     else:
          try:
               gf=Fight.objects.get(f_id=f_id)
               gf.f_number=request.POST.get('f_number')
               gf.f_multiplier=request.POST.get('f_multiplier')
               gf.save()
               data='update'
          except Exception as e:
               print(e)
               data='Not Found'
  
     return JsonResponse({'data':data})




def decla_games(request):
     games=Games.objects.all().filter()
     for g in games:
          g.g_created = g.g_created.strftime("%Y-%m-%d %I:%M %p")
     context={
          'page':'DECLA GAMES',
          'game_frm':GameForm(),
          'games':list(games)
     }
     return render(request,'ugs_app/homepage/decla_games.html',context)

@csrf_exempt
def load_games(request):

     ggames=Games.objects.all().order_by('-g_created')
     # for g in ggames:
     #      g.g_created = g.g_created.strftime("%Y-%m-%d %I:%M %p")
     ldata=serialize('json',ggames)
     gdata=json.loads(ldata)
     data='potaka'
     return JsonResponse(gdata,safe=False)


@csrf_exempt
def getgame(request):
     gid=request.POST.get('gid')
     print(gid)
     upgames=Games.objects.get(g_id=gid)
     # data=upgames
     # ldata=serialize('json',upgames)
     # data=json.loads(ldata)
     data={
          'gname':upgames.g_name,
          'meron':upgames.g_redname,
          'wala':upgames.g_bluename,
          'plasada':upgames.g_plasada,
          'desc':upgames.g_desc,
          'category':upgames.g_category,
          'link':upgames.g_link,
          'image':str(upgames.g_image),
          'status':upgames.g_status
          
     }

     return JsonResponse({'data':data})

# declarator
@csrf_exempt
def add_games(request):
     if request.method =='POST':
          gform=GameForm(request.POST, request.FILES)
          if gform.is_valid():
               games = gform.save(commit=False)
               # games.g_created=datetime.datetime.now()
               games.g_by=request.user.id
               games.save()
               data='ok'
          else:
               data='bad'
               print('bad')
     return JsonResponse({'data':str(data)})

# declarator
@csrf_exempt
def update_games(request):
     if request.method =='POST':
          gform=GameForm(request.POST, request.FILES)
          games=Games.objects.get(g_id=request.POST.get('g_id'))
          if request.FILES.get('g_image') is None:
               games.g_name=request.POST.get('g_name')
               games.g_redname=request.POST.get('g_redname')
               games.g_bluename=request.POST.get('g_bluename')
               games.g_plasada=request.POST.get('g_plasada')
               games.g_desc=request.POST.get('g_desc')
               games.g_category=request.POST.get('g_category')
               games.g_link=request.POST.get('g_link')
               games.g_status=request.POST.get('g_status')
               games.save()
               data='ok'
          else:
               if gform.is_valid():
                    games.g_image=request.FILES.get('g_image')
                    games.g_name=request.POST.get('g_name')
                    games.g_redname=request.POST.get('g_redname')
                    games.g_bluename=request.POST.get('g_bluename')
                    games.g_plasada=request.POST.get('g_plasada')
                    games.g_desc=request.POST.get('g_desc')
                    games.g_category=request.POST.get('g_category')
                    games.g_link=request.POST.get('g_link')
                    games.g_status=request.POST.get('g_status')
                    games.save()
                    data='ok'
               else:
                    data='Not Valid'

     return JsonResponse({'data':str(data)})

@csrf_exempt
def auth_user(request):
     form = LoginForm(request.POST or None)
     msg=''
     if request.method == 'POST':
          if form.is_valid():
               username=form.cleaned_data.get('username')
               password=form.cleaned_data.get('password')
               user=authenticate(username=username, password=password)
               if user is not None:
                    if user.useraccount.status == 'INACTIVE':
                         msg='inactive'
                    else:
                         msg='login'
                         login(request,user)
                         status=1
               else:
                    status=0
                    msg='err'
          else:
              status=0
              msg='err'

     return JsonResponse({'data':msg})


def signout(request):
    logout(request)
    return redirect('/')


@csrf_exempt
def account_reg(request):
    code=get_random_string(10)
    referral_link=request.META['HTTP_HOST']+'/registration/'+code
    token=get_random_string(6)
    form=SignUpForm()
    userform=UserForm()
    walletform=WalletForm()
    if request.method=='POST':
       account = SignUpForm(data=request.POST)
       userinfo = UserForm(data=request.POST)
     #   wallet=WalletForm(data=request.POST)
     #   print(request.POST.get('contact_no'))
       if account.is_valid() and userinfo.is_valid() :
            user = account.save()
            user.set_password(user.password)
            user.save()
            info = userinfo.save(commit = False)
            info.user = user
            info.usertype=request.POST.get('usertype')
            info.relpass=request.POST.get('password')
            info.referral_code=code
            info.referral_link=referral_link
            info.user_agent=request.user
            info.status='INACTIVE'
            info.save()
            wall=walletform.save(commit = False)
            wall.user=user
            wall.w_balance=0
            wall.w_points=0
            wall.w_commission=0
            wall.w_status='ACTIVE'
            wall.save()
            data='ok'
           
       else:
            data='Error Validating'
    else:
          data=request

    return JsonResponse({'data':data})



@csrf_exempt
def lastcall(request):
     gfid=request.POST.get('gfight')
     # print(gfid)
     cfight=Fight.objects.get(f_id=gfid)
     cfight.f_status='LAST CALL'
     cfight.save()
     data=cfight.f_status
     return JsonResponse({'data':data})

@csrf_exempt
def closebet(request):
     gfid=request.POST.get('cfight')
     print(gfid)
     cfight=Fight.objects.get(f_id=gfid)
     cfight.f_status='CLOSE'
     cfight.save()
     data=cfight.f_status
     return JsonResponse({'data':data})

@csrf_exempt
def openbet(request):
     ofid=request.POST.get('ofight')
     print(ofid)
     cfight=Fight.objects.get(f_id=ofid)
     cfight.f_status='DONE'
     cfight.save()
     game=cfight.f_game
     fnum=cfight.f_number
     addf=Fight(f_number=fnum +1,f_game=game,f_winner='',f_status='OPEN').save()
     
     data=cfight.f_status
     return JsonResponse({'data':data})

# DECLA UPDATE FIGHT STATUS /////////
@csrf_exempt
def fight_stat(request):
     fid=request.POST.get('fid')
     typ=request.POST.get('typ')
     try:
          fight=Fight.objects.get(f_id=fid)
          fight.f_status=typ
          fight.save()
          data=1
     except Exception as e:
          data=0

     return JsonResponse({'data':data})

@csrf_exempt
def setwinner(request):
     fid=request.POST.get('fight')
     winner=request.POST.get('winner')
     try:
          gfight=Fight.objects.get(f_id=fid)
          gfight.f_winner=winner
          gfight.f_status='DECLARED'
          gfight.save()
          data='ok'
     except Exception as e:
          data='bad'
     
     return JsonResponse({'data':data})

@csrf_exempt
def revert(request):
     fid=request.POST.get('fight')
     try:
          gfight=Fight.objects.get(f_id=fid)
          gfight.f_winner=''
          gfight.f_status='CLOSING'
          gfight.save()
          data='ok'
     except Exception as e:
          data='bad'
 
     return JsonResponse({'data':data})

# disbusement

@csrf_exempt
def disburse(request):
     fid=request.POST.get('fight')
     try:
          gfight=Fight.objects.get(f_id=fid)
          gfight.f_status='DONE'
          gfight.save()
          data='ok'
     except Exception as e:
          data='bad'
     return JsonResponse({'data':data})

@csrf_exempt
def nxtfight(request):
     fid=request.POST.get('fight')
     gid=request.POST.get('game')
     code=get_random_string(6)
     fform=FightForm()
     try:
          ggame=Games.objects.get(g_id=gid)
          try:
               gfight=Fight.objects.get(f_id=fid)
               fnum=gfight.f_number
               # data=fnum
               nwf = fform
               if nwf.is_valid:
                    nf = fform.save(commit=False)   
                    nf.f_game=ggame 
                    nf.f_number=fnum + 1
                    nf.f_code=code
                    nf.f_status='CLOSED'
                    nf.save()
                    data='ok'
          except Exception as e:
               data='bad fight'
     except Exception as e:
          data='bad'
     return JsonResponse({'data':data})

# ////////////////////////////////
@csrf_exempt
def updatewallet(request):
     amount=request.POST.get('amount')
     ttrans=request.POST.get('ttype')
     fid=request.POST.get('fid')
     betin=request.POST.get('betin')
     

     # print(type(amount))
     try:
          gwallet=UserWallet.objects.get(user=request.user)
          curbalance=gwallet.w_balance
          newbal=curbalance - int(amount)
          gwallet.w_balance=newbal
          gwallet.save()
          try: 
               fight=Fight.objects.get(f_id=fid)
               try:
                    bet=Bet.objects.create(fight=fight,amount=amount,category=betin,player=request.user)
                    print('ok')
               except Exception as e:
                    
                    print('No Bet Yet')
                    print(e)
          except Exception as e:
               print(e)
     except Exception as e:
          print(e)

     data=gwallet.w_balance
     return JsonResponse({'data':data})


def registration(request,code):
     agent=UserAccount.objects.get(referral_code=code)
     context={
          'page':'REGISTRATION',
          'code':code,
          'signup_frm':SignUpForm(),
          'user_frm':UserForm()
     
     }
     return render(request,'ugs_app/auth/registration.html',context)

@csrf_exempt
def player_reg(request):
     code=get_random_string(150)
     referral_link=request.META['HTTP_HOST']+'/registration/'+code
     walletform=WalletForm()
     account = SignUpForm(data=request.POST)
     userinfo=UserForm()

     aid=request.POST.get('code')
     try:
          agent=UserAccount.objects.get(referral_code=aid)
          if agent is not None:
               data='Exist'
               if account.is_valid():
                    user = account.save()
                    user.set_password(user.password)
                    user.save()
                    info = userinfo.save(commit = False)
                    info.user = user
                    info.usertype='PLAYER'
                    info.relpass=request.POST.get('password')
                    info.referral_code=code
                    info.referral_link=referral_link
                    info.user_agent=agent.user
                    info.status='INACTIVE'
                    info.save()
                    wall=walletform.save(commit = False)
                    wall.user=user
                    wall.w_balance=0
                    wall.w_points=0
                    wall.w_commission=0
                    wall.w_status='ACTIVE'
                    wall.save()
                    data='ok'
               else:
                    data='Form Not Valid'

     except Exception as e:
          data='Referral Agent Not Found!'

     

     return JsonResponse({'data':data})


def timer(request):
     return render(request,'ugs_app/timer.html')