$(document).ready(function(){
    const games=JSON.parse(document.getElementById('arena_game').textContent)
    const player=JSON.parse(document.getElementById('player').textContent)
    const fight_n=JSON.parse(document.getElementById('fight_n').textContent)
    const bet_s=JSON.parse(document.getElementById('betstatus').textContent)


    var socket= new WebSocket('ws://'+window.location.host+'/ws/arena/'+games);
    // /////////////////////////

    $(document).on('click','.bet',function(){
        amount = $(this).val()

        $('#mybet').val(amount)
    })

    
    // /////////////////////////
    $('.clearbet').click(function(){
        $('#mybet').val(0)
    })
    

       // //////////////////////// Close Betting
    

    // /////////////////////////
     
 
    socket.onmessage =function(e){    
        $('.notif').html('')
    
        result=JSON.parse(e.data)
        console.log(result) 

        if(result.winner == 'MERON'){
            $('.meron_box').addClass('meron-win')
            $('.wala_box').removeClass('wala-win')
            $('.draw_box').removeClass('draw-win')
        }else if(result.winner == 'WALA'){
            $('.meron_box').removeClass('meron-win')
            $('.draw_box').removeClass('draw-win')
            $('.wala_box').addClass('wala-win')
        }else if(result.winner == 'DRAW'){
            $('.draw_box').addClass('draw-win')
            $('.meron_box').removeClass('meron-win')
            $('.wala_box').removeClass('wala-win')
        }else{
            $('.meron_box').removeClass('meron-win')
            $('.wala_box').removeClass('wala-win')
            $('.draw_box').removeClass('draw-win')
        }

        $('#fid').val(result.fightid)
        $('#wbalance').val(result.mywallet)
        $('.wbalance').text(result.mywallet)

        if(result.bet_status == 'OPEN'){
           $('.betsub').removeClass('disabled')
            notif='<span class="badge bg-success fw-bolder fs-4 " >OPEN</span>'
        }else if(result.bet_status == 'LAST CALL'){
            $('.betsub').removeClass('disabled')
            notif='<span class="badge bg-warning text-danger fw-bolder fs-4  blink callnotif" >LAST CALL</span>'
        }else if(result.bet_status == 'CLOSED'){
            $('.betsub').addClass('disabled')
            notif=' <span class="badge bg-danger fw-bolder fs-4    closenotif" >CLOSED</span>'
        }else if(result.bet_status == 'CLOSING'){
            $('.betsub').addClass('disabled')
            notif=' <span class="badge bg-danger fw-bolder fs-4    closenotif" >CLOSED</span>'
        }else if(result.bet_status == 'DECLARED'){
            $('.betsub').addClass('disabled')
            notif=' <span class="badge bg-danger fw-bolder fs-4    closenotif" >CLOSED</span>'
        }else if(result.bet_status == 'DONE'){
            notif=' <span class="badge bg-danger fw-bolder fs-4    closenotif" >CLOSED</span>'
            $('.betsub').addClass('disabled')
            $('.meron_box').removeClass('meron-win')
            $('.wala_box').removeClass('wala-win')
            $('.draw_box').removeClass('draw-win')
        }
        
        $('.notif').append(notif)


        $('.fnum').text('Fight #: '+result.fightnum)
        $('.meronpayout').text(result.meronpayout.toFixed(2))
        $('.walapayout').text(result.walapayout.toFixed(2))

        $('.merontowin').text(result.merontowin.toFixed(2))
        $('.walatowin').text(result.walatowin.toFixed(2))

        $('#wbalance').val(result.mywallet)
        $('.wbalance').text(result.mywallet.toLocaleString('en'))
        

        meron = $('.meron-val').val()
        $('.meron_bet').text(result.dmeron)
        $('.meron-val').val(result.dmeron)

        $('.meron_bet').each(function () {
            $(this).prop('Counter',meron).animate({
                Counter: $(this).text()
            }, {
              
              //chnage count up speed here
                duration: 1000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                    
                }
                
            })
        });

        wala = $('.wala-val').val()
        $('.wala_bet').text(result.dwala)
        $('.wala-val').val(result.dwala)

        $('.wala_bet').each(function () {
            $(this).prop('Counter',wala).animate({
                Counter: $(this).text()
            }, {
              
              //chnage count up speed here
                duration: 1000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                    
                }
                
            })
        });

        draw = $('.draw-val').val()
        $('.mydrawbet').text(result.mydrawbet)
        $('.draw-val').val(result.mydrawbet)
       
        $('.mydrawbet').each(function () {
            $(this).prop('Counter',draw).animate({
                Counter: $(this).text()
            }, {
              
              //chnage count up speed here
                duration: 2000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                    
                }
                
            })
        });

        long = $('.long-val').val()
        $('.mylongbet').text(result.mylongbet)
        $('.long-val').val(result.mylongbet)
       
        $('.mylongbet').each(function () {
            $(this).prop('Counter',long).animate({
                Counter: $(this).text()
            }, {
              
              //chnage count up speed here
                duration: 2000,
                easing: 'swing',
                step: function (now) {
                    $(this).text(Math.ceil(now).toLocaleString('en'));
                    
                }
                
            })
        });
        
        $('.mymeronbet').text(result.myMeronBet.toLocaleString('en'))
        $('.mywalabet').text(result.myWalaBet.toLocaleString('en'))
        $('.mydrawbet').text(result.mydrawbet.toLocaleString('en'))
        $('.mylongbet').text(result.mylongbet.toLocaleString('en'))
        
    }
    socket.onopen = function(e){
       

    $(document).on('click','.betsub',function(){
       
        amount=$('#mybet').val()
        betamount=parseFloat(amount)
        fid=$('#fid').val()
        betin=$(this).attr('id')
        wallet=$('#wbalance').val()
       
        if(betamount > wallet){

            Swal.fire({
                title: "insufficient Points Balance!",
                icon: "error"
                });
            
        }else{

            // ///////////
            if(betamount == 0){
                Swal.fire({
                        title: "No Amount Entered!",
                        icon: "error"
                        });
            }else{
                Swal.fire({
                    title: "BET "+betin +" : " +betamount+" ?",
                    text: "You're to place a Bet",
                    icon: "warning",
                    showCancelButton: true,
                    confirmButtonColor: "#3085d6",
                    cancelButtonColor: "#d33",
                    confirmButtonText: "Proceed!"
                    }).then((result) => {
                    if (result.isConfirmed) {
                        $('#mybet').val(0)
                        st=$('#betst').val()
                        // ///////////////////////////
                        if(st == 'CLOSE'){
                            Swal.fire({
                                title: "Betting are Closed!",
                                icon: "error"
                                });
    
                        }else{
                            $.ajax({
                                method:'POST',
                                url:'../../updatewallet',
                                data:{amount:amount,ttype:'minus',fid:fid,betin:betin},
                                success:function(res){
                                    socket.send(JSON.stringify({
                                        'amount': betamount,
                                        'betin':betin,
                                        'player':player,
                                        'fight_no':fid,
                                        // 'bet_stat':$('#betst').val(),
            
                                    }))
                                }
                            })
                            
                        }
        
                        // //////////////////////////
                    }
                    });
                    
            }

            // //////////

        }

        

        

    })

}
    // /////////////////////////////
})