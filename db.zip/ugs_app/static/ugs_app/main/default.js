$(document).ready(function(){
    // //////////////////

    // $(document).on('click','.playnow',function(){
    //     gid=$(this).attr('id')

    //     alert(gid)
    // })


    // /////////////////
})