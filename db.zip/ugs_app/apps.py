from django.apps import AppConfig


class UgsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ugs_app'
